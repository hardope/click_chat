<center><img src="https://hardope.pythonanywhere.com/static/icon.png" width=60 style="border-radius: 25px"></center>

# Click Chat

Social Media Platform & Instant Messaging Web Application<br>

[Link to website](https://hardope.pythonanywhere.com)

---

I'm Currently Developing an Updated Version Using Python Django FrameWork

Repo at [ClickViral](https://github.com/hardope/viral)

Prototype (Under Development) at [ClickViral](https://clickviral.pythonanywhere.com)

---

## Design & Development

Design and development of a full scale social media patform Using Python flask web framework.<br>

This web app enables users to create text and picture posts and comments which can be liked and unliked. The comment section is multi layered as each comment can can aslo have a comment.<br>

Each user has a username and password, and after account creation, each user can upload a profile picture and give details about themselves like their sex and bio.<br>

The instant messenger refreshes every second transfering messages among users at the speed of light. The messenger sends requests to the server to fetch and send messages.<br>

New message notification achieved by sending requests by the second to the server to confirm if new messages are awaiting the user.

---

### Tech Stack Used In development
* Python Flask
* SQLite
* HTML
* CSS
* Javascript

---

### Features
* Creating posts with support for text, Images and Videos
* Instant Messaging: Refreshes Every Second
* Like and & unlike posts
* Multi Layered comments with support for pictures
* Like and unlike comments
* Average User Interface and Experience (I'm Not very experienced on the front end)
* Unread Messages Notifications refreshing By the second.


### Note:
Flask app not present in repository for personal reasons.<br>
This Web App also ustilizes a database which is also absent for security reasons.
